<?php

  require(CMODELO."directivas.php");
  require(CMODELO.'datosAuxiliares.php');

  $modelDirectives=new Directivas();

  //Tablas auxiliares o tablas hijas
  $generoModel  = new Genero();
  $estadoCivilModel = new EstadoCilvil();
  $epsModel =  new Eps();
  $barrioModel = new Barrio();
  $jornadaModel = new Jornada();
  $rolModel = new Rol();
  $TipoDocumentoModel = new TipoDocumento();

  function convertDataJson($estado , $data){
    return json_encode( array( "estado" => $estado , "msg" => $data ) );
  }

  function verificErrosColumns($valueFile, $dataBd , int $indexBd){
    $val = 0;
    $err=0;
    foreach ($dataBd as  $valueBd) {
        if( strtolower($valueFile) == strtolower($valueBd[ $indexBd ]) ) { $val = $valueBd[0] ; break; }else{ $val = false; } 
      }//end foreach
      
      //capturamos la cantidad de errores
      return ( $val == false ) ?  1 : $err  ;
  }


  switch (isset($_GET["acciones"]) ? $_GET["acciones"] : null) {
    
    case 'listardirectivas':
      $res=$modelDirectives->lisDirectivas();

      if(count( $res ) == 0){
        echo convertDataJson( false , $res );
      }else{
        $data = null;
          for ($i=0; $i<count($res); $i++) {
            $arregloEliminar = json_encode(array("008id"=> $res[$i]['008id'] , "nombres"=> $res[$i]['008nombres'] , "documento"=> $res[$i]['008documento']  ));
            $data .= '
            <tr class="animated fadeIn">
              <!-- <input type="hidden" name="datos" value=""> -->
              <td>'. $res[$i]["008nombres"] .'</td>
              <td>'. $res[$i]["008apellidos"] .'</td>
              <td>'. $res[$i]["008documento"] .'</td>
              <td>'. $res[$i]["0019desTipo"] .'</td>
              <td>'. $res[$i]["008telFijo"] .'</td>
              <td>'. $res[$i]["008celular"] .'</td>
              <td>'. $res[$i]["008email"] .'</td>
              <td>'. $res[$i]["008direccion"] .'</td>
              <td>'. $res[$i]["0010desBarrio"] .'</td>
              <td>'. $res[$i]["0015desJornada"] .'</td>
              <td>'. $res[$i]["009desUsu"] .'</td>


              <td>
                <a href="#modalFrmData" class="btn  btn-primary btn-sm btn-edit" data-toggle="modal" data=\' '.json_encode($res[$i]).' \' > <span class="fa fa-edit"></span>
                </a>
              </td>

              <td>
                <a href="#" class="btn btn-danger btn-sm btn-remove" data=\' '.  $arregloEliminar  .' \' ><span class="fa fa-trash"  ></span>
                </a>
              </td>

            </tr>
            ';
          }  //end for
          echo convertDataJson( true , $data );
        }

      break;

    case 'updateDirectivas':
      $response = array();
      try {
          $modelDirectives->setAll($_POST['nombre'],
                                   $_POST['apellido'],
                                   $_POST['fechaNacimiento'],
                                   $_POST['genero'],
                                   $_POST['estadoCivil'],
                                   "",
                                   $_POST['email'],
                                   $_POST['celular'],
                                   $_POST['eps'] ,
                                   $_POST['tel'],
                                   $_POST['direccion'],
                                   $_POST['barrio'] ,
                                   $_POST['nombreAcu'] ,
                                   $_POST['apellidoAcu'] ,
                                   $_POST['celularAcu'],
                                   $_POST['telAcu'],
                                   $_POST['jornada'] ,
                                   $_POST['documento'],
                                   $_POST['rol'],
                                   $_POST['tipoDocumento']);
          $modelDirectives->SetIdDoc( $_POST['idDirectiva'] , $_POST['documento']);
          $response =  array( true , $modelDirectives->editDirectivas() ) ;
      } catch (Exception $e) {
        $response = array( false , $e->getMessage());
      }finally{
        echo convertDataJson( $response[0], $response[1] );
      }
      break;

    case 'newDirectiva':
      $response = null;
      try {
        $modelDirectives->setAll(  $_POST['nombre'],
                                   $_POST['apellido'],
                                   $_POST['fechaNacimiento'],
                                   $_POST['genero'],
                                   $_POST['estadoCivil'],
                                   "",
                                   $_POST['email'],
                                   $_POST['celular'],
                                   $_POST['eps'] ,
                                   $_POST['tel'],
                                   $_POST['direccion'],
                                   $_POST['barrio'] ,
                                   $_POST['nombreAcu'] ,
                                   $_POST['apellidoAcu'] ,
                                   $_POST['celularAcu'],
                                   $_POST['telAcu'],
                                   $_POST['jornada'] ,
                                   $_POST['documento'],
                                   $_POST['rol'],
                                   $_POST['tipoDocumento']);
        $response =  $modelDirectives->nuevaDirectiva();
        $response = ( $response === 9 && $response != 1 ) ? array( true , 9 ) : array( true , true );
      } catch (Exception $e) {
        $response = array( false , $e->getMessage());
      }finally{
        echo convertDataJson( (bool)$response[0] , $response[1] );

      }
    
      break;

    case 'deleteDirective':
      $response = null;
      try {
        //var_dump($_POST);
        $modelDirectives->SetIdDoc( $_POST['idDirective'] , $_POST['documento'] );
        $da = $modelDirectives->eliDirectivas();
        $response = array( true ,true  );
      } catch (Exception $e) {
        $response = array( false , $e->getMessage() );
      }finally{
        echo convertDataJson( $response[0]  , $response[1] );
      }
      
       
      break;

    case 'sevaFileCvs':

      
        try {
          $response = null;
          if( $_FILES['fileDirective']['type'] == "text/csv" ){
            $fecha = date('m/d/Y g:ia');
          
            $nombreArchive = str_replace(["/" , " "], "-", $fecha . "-" .$_FILES['fileDirective']['name']);
            $rutaservidorTemporal = RUTALINUX."view/app/csv/csvDirectivas/".$nombreArchive;
           // $rutaservidorTemporal = RUTALINUX."view/app/csv/csvDirectivas/".$_FILES['fileDirective']['name'];
            $rutaBd = "view/app/imagenes/Thumbnail/".$nombreArchive; //windows
           // echo $rutaservidorTemporal;

            if( move_uploaded_file($_FILES['fileDirective']['tmp_name'], $rutaservidorTemporal ) ){
            
              $row = 1;
              $fp = fopen($rutaservidorTemporal, "r");   //abrimos el archivo
              $fp1 = fopen($rutaservidorTemporal, "r");

              //Variables de error
              $errGenero = 0;
              $errEstadoCivil = 0;
              $errEps = 0;
              $errBarrio = 0;
              $errJornada = 0;
              $errRol = 0;
              $errTipoDocumento = 0;

              $valGenero = 0;
              $valEstadoCivil = 0;
              $valEps = 0;
              $valBarrio = 0;
              $valJornada = 0;
              $valRol = 0;
              $valTipoDocumento = 0;


              //creamos arreglos para capturar los erros de documentos o correos existentes
              $errDocuemntoExist = array();
              $errCorreoExist = array();


                if( count(fgetcsv($fp1, 1000 , ",") ) >  21 || count(fgetcsv($fp1 , 1000 , ",") ) < 21  ){
                  $response = array(false , "notColumns" );
                  throw new Exception("notColumns");
                  //exit
                }

              while($data = fgetcsv($fp , 10000 , ",") ){
                if($row != 1){ //seranecho las cabezeras del documento excel

                 if( verificErrosColumns($data[4] ,$generoModel->listarGenero() , 1)  == 1 )  $errGenero++;
                 if( verificErrosColumns($data[5] ,$estadoCivilModel->listEstadoCivil() , 1)  == 1 )  $errEstadoCivil++;
                 if( verificErrosColumns($data[9] ,$epsModel->listarEps() , 1)  == 1 )  $errEps++;
                 if( verificErrosColumns($data[12] ,$barrioModel->listBarrioAll() , 1)  == 1 )  $errBarrio++;
                 if( verificErrosColumns($data[17] ,$jornadaModel->listarJornada() , 1)  == 1 )  $errJornada++;
                 if( verificErrosColumns($data[19] ,$rolModel->listarRoles() , 1)  == 1 )  $errRol++;
                 if( verificErrosColumns($data[20] ,$TipoDocumentoModel->listarTD() , 1)  == 1 )  $errTipoDocumento++;
                

                //RECORDAR VALIDAR SI LOS REGISTROS DE LA BASE DE DATOS SON IAGUALES AL DEL ARCHIVO NO REMPLAZARLOS MANDAR ALERTA DICIENDO EL NOMBRE DE TAL YA ESTA EN EL SISTEMA 
                //Validar Tipo si el documento ya existe ene el sistema y mostrar que docuemnto ya existe



                  $dataModel = $modelDirectives->validateDocumentEmailExists( $data[18] , $data[7] );

                  json_encode($dataModel);

                  if( $dataModel["correo"] == "email" ){
                    $errCorreoExist[] = array( "correo" => $data[7]  , "nombre" =>  $data[1] . " " .$data[2] ); 
                    continue;
                  }

                  if($dataModel["documento"] == "doc" ){  // el doicumento existe
                    $errDocuemntoExist[] = array( "docFile" => $data[18]  , "nombre" =>  $data[1] . " " .$data[2] ); 
                  } 
                  



                 
                } // hader de la tablas if == 1
                
                $row++;
              }//end while


            if(  $errGenero > 0 || $errEstadoCivil > 0 || $errEps > 0 || $errBarrio > 0 || $errJornada > 0 || $errRol > 0 || $errTipoDocumento > 0   ){
                $response = array( false ,  array( 
                "errGenero"=>$errGenero,
                "errEstadoCivil"=>$errEstadoCivil,
                "errEps"=>$errEps,
                "errBarrio"=>$errBarrio,
                "errJornada"=>$errJornada,
                "errRol"=>$errRol,
                "errTipoDocumento" => $errTipoDocumento
               ) );                
            }else {

                  $response = array( true , array( $errDocuemntoExist  ,  $errCorreoExist ) );

             // $response = array(true,true);


            }

            
            }else{
              throw new Exception("Error al cargar el archivo");
            }
          }else{
            $response = array( true , "Tipo de archivo no valido , seleccione un archivo csv para continuar." );
          }
        } catch (Exception $e) {
             $response=array( false , $e->getMessage() );
        }finally{
          echo convertDataJson( $response[0] , $response[1] );
          fclose($fp1);
          fclose($fp);
        }




      break;

    default:
        echo convertDataJson( false, "Error 404 ruta no encontrada, vuelva a intentarlo" );
      break;
  }

 ?>
